// Salon information object
let salon = {
    name: "Fashion Pet",
    phone: "999-999-9999",
    address: {
        street: "palm st",
        number: "1642",
        zip: "89102"
    },
    pets: []

}
function displayFooterInfo(){
    document.getElementById("info").innerHTML = `
    <p>Welcome to the ${salon.name}, located at${salon.address.street} ${salon.address.number} ${salon.address.zip}</p>
    `;
}

displayFooterInfo();